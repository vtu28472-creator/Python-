cls = float(input("Enter temperature in Celsius: "))
fah = (cls * 1.8) + 32
print("%0.1f degrees Celsius is equal to %0.1f degrees Fahrenheit." % (cls, fah))

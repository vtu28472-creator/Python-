a = int(input("enter total number of loaves per day\n"))
r = 185 * a
d = 0.6 * r
t = 0.4 * r
print("Regular Price ", r)
print("Total Discount ", d)
print("Total Amount to be paid ", t)
